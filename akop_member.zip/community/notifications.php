<?php
header('Content-Type: application/json');
require '../config.php';

function decryptLaravelData($payload, $appKeyBase64) {
    try {
        $key = base64_decode(substr($appKeyBase64, 7));
        $data = json_decode(base64_decode($payload), true);
        if (!$data || !isset($data['iv'], $data['value'])) return null;
        $iv = base64_decode($data['iv']);
        $value = $data['value'];
        $decrypted = openssl_decrypt($value, 'aes-256-cbc', $key, 0, $iv);
        if ($decrypted === false) return null;
        $unserialized = @unserialize($decrypted);
        return ($unserialized !== false) ? $unserialized : $decrypted;
    } catch (Exception $e) { return null; }
}

$appKey = "base64:NusO0N5yu2WM4bbP7qDg9DfJc9FpglsPgtvSapEHxpM=";

$userId = $_GET['user_id'] ?? '';

if (empty($userId)) {
    echo json_encode(["status" => "error", "message" => "user_id required"]);
    exit;
}

$stmt = $conn->prepare("SELECT n.*, u.contact, u.m_fname, u.m_surname, p.content AS post_preview
    FROM community_notifications n
    LEFT JOIN tblcrms u ON n.from_user_id = u.id
    LEFT JOIN community_posts p ON n.post_id = p.id
    WHERE n.user_id = ?
    ORDER BY n.created_at DESC
    LIMIT 50");
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();

$notifications = [];
while ($row = $result->fetch_assoc()) {
    $fname = decryptLaravelData($row['m_fname'] ?? '', $appKey);
    $sname = decryptLaravelData($row['m_surname'] ?? '', $appKey);
    $fullName = trim(($fname ?? '') . ' ' . ($sname ?? ''));

    $notifications[] = [
        'id'           => $row['id'],
        'type'         => $row['type'],
        'post_id'      => $row['post_id'],
        'comment_id'   => $row['comment_id'],
        'is_read'      => (bool) $row['is_read'],
        'created_at'   => $row['created_at'],
        'from_user'    => [
            'id'        => $row['from_user_id'],
            'contact'   => $row['contact'],
            'full_name' => $fullName ?: ($row['contact'] ?? 'Unknown'),
        ],
        'post_preview' => mb_strimwidth($row['post_preview'] ?? '', 0, 80, '...'),
    ];
}

// Mark all as read
$conn->query("UPDATE community_notifications SET is_read = 1 WHERE user_id = $userId");

echo json_encode(["status" => "success", "data" => $notifications]);